<?xml version="1.0" ?><!DOCTYPE TS><TS language="fr" version="2.1">
<context>
    <name>Command line arguments</name>
    <message>
        <source>Wayland compositor for the Hawaii desktop environment</source>
        <translation>Compositeur Wayland pour l&apos;environnement de bureau Hawaii</translation>
    </message>
    <message>
        <source>Synthesize touch for unhandled mouse events</source>
        <translation>Synthétiser une touche pour les évènements de souris non gérés</translation>
    </message>
    <message>
        <source>Full screen compositor window</source>
        <translation>Compositeur de fenêtre plein écran</translation>
    </message>
    <message>
        <source>Idle time in seconds (at least 5 seconds)</source>
        <translation>Temps d&apos;inactivité en secondes (au moins 5 secondes)</translation>
    </message>
    <message>
        <source>secs</source>
        <translation>secondes</translation>
    </message>
</context>
</TS>