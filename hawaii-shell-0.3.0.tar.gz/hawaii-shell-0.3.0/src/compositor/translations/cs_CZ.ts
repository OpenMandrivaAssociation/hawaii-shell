<?xml version="1.0" ?><!DOCTYPE TS><TS language="cs_CZ" version="2.1">
<context>
    <name>Command line arguments</name>
    <message>
        <source>Wayland compositor for the Hawaii desktop environment</source>
        <translation>Sazeč Wayland pro pracovní prostředí Hawaii</translation>
    </message>
    <message>
        <source>Synthesize touch for unhandled mouse events</source>
        <translation>Vytvořit dotek pro nezpracované události myši</translation>
    </message>
    <message>
        <source>Full screen compositor window</source>
        <translation>Okno sazeče na celou obrazovku</translation>
    </message>
    <message>
        <source>Idle time in seconds (at least 5 seconds)</source>
        <translation>Doba nečinnosti v sekundách (alespoň 5 sekund)</translation>
    </message>
    <message>
        <source>secs</source>
        <translation>s</translation>
    </message>
</context>
</TS>