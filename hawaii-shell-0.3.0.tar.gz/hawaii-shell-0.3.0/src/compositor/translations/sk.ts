<?xml version="1.0" ?><!DOCTYPE TS><TS language="sk" version="2.1">
<context>
    <name>Command line arguments</name>
    <message>
        <source>Wayland compositor for the Hawaii desktop environment</source>
        <translation>Wayland kompozitor pre pracovné prostredie Hawaii</translation>
    </message>
    <message>
        <source>Synthesize touch for unhandled mouse events</source>
        <translation>Vytvoriť dotyk pre nespracované udalosti myši</translation>
    </message>
    <message>
        <source>Full screen compositor window</source>
        <translation>Okno kompozitora na celú obrazovku</translation>
    </message>
    <message>
        <source>Idle time in seconds (at least 5 seconds)</source>
        <translation>Doba nečinnosti v sekundách (aspoň 5 sekúnd)</translation>
    </message>
    <message>
        <source>secs</source>
        <translation>sek.</translation>
    </message>
</context>
</TS>