<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt_BR" version="2.1">
<context>
    <name>Command line arguments</name>
    <message>
        <source>Wayland compositor for the Hawaii desktop environment</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Synthesize touch for unhandled mouse events</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Full screen compositor window</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Idle time in seconds (at least 5 seconds)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>secs</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>