<?xml version="1.0" ?><!DOCTYPE TS><TS language="ast_ES" version="2.1">
<context>
    <name>AppCategories</name>
    <message>
        <source>Sound &amp; Video</source>
        <translation>Soníu y vidéu</translation>
    </message>
    <message>
        <source>Sound</source>
        <translation>Soníu</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Vidéu</translation>
    </message>
    <message>
        <source>Programming</source>
        <translation>Programación</translation>
    </message>
    <message>
        <source>Education</source>
        <translation>Educación</translation>
    </message>
    <message>
        <source>Game</source>
        <translation>Xuegu</translation>
    </message>
    <message>
        <source>Graphics</source>
        <translation>Gráficos</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Rede</translation>
    </message>
    <message>
        <source>Office</source>
        <translation>Oficina</translation>
    </message>
    <message>
        <source>Science</source>
        <translation>Ciencia</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Axustes</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <source>Utilities</source>
        <translation>Utilidaes</translation>
    </message>
</context>
<context>
    <name>AuthenticationDialog</name>
    <message>
        <source>Authentication required</source>
        <translation>Requierse autenticación</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Encaboxar</translation>
    </message>
    <message>
        <source>Authenticate</source>
        <translation>Autenticar</translation>
    </message>
</context>
<context>
    <name>Command line parser</name>
    <message>
        <source>Enable QML JavaScript debugger.</source>
        <translation>Habilitar depurador QML JavaScript.</translation>
    </message>
</context>
<context>
    <name>NotificationsPanel</name>
    <message>
        <source>Notifications</source>
        <translation>Notificaciones</translation>
    </message>
</context>
<context>
    <name>PolicyKitAgent</name>
    <message>
        <source>Administrator</source>
        <translation>Alministrador</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Conseña:</translation>
    </message>
    <message>
        <source>Sorry, that didn&apos;t work. Please try again.</source>
        <translation>Perdón, ésto nun furruló. Por favor, inténtalo otra vegada.</translation>
    </message>
</context>
<context>
    <name>ShutdownDialog</name>
    <message>
        <source>The system will power off automatically in %1 seconds.</source>
        <translation>El sistema apagaráse automáticamente en %1 segundos.</translation>
    </message>
    <message>
        <source>Power Off</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Encaboxar</translation>
    </message>
    <message>
        <source>Restart</source>
        <translation>Reaniciar</translation>
    </message>
</context>
<context>
    <name>WindowsSwitcherOverlay</name>
    <message>
        <source>Untitled</source>
        <translation>Ensin títulu</translation>
    </message>
</context>
</TS>