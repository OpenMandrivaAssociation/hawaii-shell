#!/bin/sh
lupdate -no-obsolete -locations none .. -ts template.ts
