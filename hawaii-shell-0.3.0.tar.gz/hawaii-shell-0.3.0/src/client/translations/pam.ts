<?xml version="1.0" ?><!DOCTYPE TS><TS language="pam" version="2.1">
<context>
    <name>AppCategories</name>
    <message>
        <source>Sound &amp; Video</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Sound</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Programming</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Education</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Game</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Graphics</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Network</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Office</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Science</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>System</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Utilities</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>AuthenticationDialog</name>
    <message>
        <source>Authentication required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Authenticate</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Command line parser</name>
    <message>
        <source>Enable QML JavaScript debugger.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>NotificationsPanel</name>
    <message>
        <source>Notifications</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PolicyKitAgent</name>
    <message>
        <source>Administrator</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Password:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Sorry, that didn&apos;t work. Please try again.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ShutdownDialog</name>
    <message>
        <source>The system will power off automatically in %1 seconds.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Power Off</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Restart</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>WindowsSwitcherOverlay</name>
    <message>
        <source>Untitled</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>